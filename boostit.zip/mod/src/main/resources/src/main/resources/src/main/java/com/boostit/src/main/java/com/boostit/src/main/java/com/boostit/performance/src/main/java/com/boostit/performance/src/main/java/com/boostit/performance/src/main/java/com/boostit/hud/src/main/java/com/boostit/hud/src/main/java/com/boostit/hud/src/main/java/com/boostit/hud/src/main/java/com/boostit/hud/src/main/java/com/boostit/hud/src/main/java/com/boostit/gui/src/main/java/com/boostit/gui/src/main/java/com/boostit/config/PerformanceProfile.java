package com.boostit.config;

public enum PerformanceProfile {
    QUALITY("Quality", 12, 8, true, true),
    BALANCED("Balanced", 10, 6, true, false),
    PERFORMANCE("Performance", 8, 4, false, false),
    EXTREME("Extreme", 4, 2, false, false);

    private final String name;
    private final int renderDistance;
    private final int simulationDistance;
    private final boolean entityShadows;
    private final boolean fancyGraphics;

    PerformanceProfile(String name, int renderDistance, int simulationDistance, boolean entityShadows, boolean fancyGraphics) {
        this.name = name;
        this.renderDistance = renderDistance;
        this.simulationDistance = simulationDistance;
        this.entityShadows = entityShadows;
        this.fancyGraphics = fancyGraphics;
    }

    public String getName() { return name; }
    public int getRenderDistance() { return renderDistance; }
    public int getSimulationDistance() { return simulationDistance; }
    public boolean hasEntityShadows() { return entityShadows; }
    public boolean hasFancyGraphics() { return fancyGraphics; }
}
