package com.boostit.gui;

import com.boostit.config.PerformanceProfile;
import com.boostit.config.ProfileManager;
import com.boostit.optimization.AutoOptimizer;
import com.boostit.performance.PerformanceMonitor;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class BoostItScreen extends Screen {

    public BoostItScreen() {
        super(Text.literal("BOOSTIT Dashboard"));
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int centerY = this.height / 2;

        this.addDrawableChild(ButtonWidget.builder(Text.literal("RUN AUTO-OPTIMIZER"), button -> {
            AutoOptimizer.runAutoOptimization();
        }).dimensions(centerX - 100, centerY + 40, 200, 20).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Quality"), button -> {
            ProfileManager.getInstance().applyProfile(PerformanceProfile.QUALITY);
        }).dimensions(centerX - 105, centerY + 70, 50, 20).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Balanced"), button -> {
            ProfileManager.getInstance().applyProfile(PerformanceProfile.BALANCED);
        }).dimensions(centerX - 50, centerY + 70, 50, 20).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Perf"), button -> {
            ProfileManager.getInstance().applyProfile(PerformanceProfile.PERFORMANCE);
        }).dimensions(centerX + 5, centerY + 70, 50, 20).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Extreme"), button -> {
            ProfileManager.getInstance().applyProfile(PerformanceProfile.EXTREME);
        }).dimensions(centerX + 60, centerY + 70, 50, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context);

        int centerX = this.width / 2;
        PerformanceMonitor monitor = PerformanceMonitor.getInstance();

        context.drawCenteredTextWithShadow(this.textRenderer, "BOOSTIT PERFORMANCE DASHBOARD", centerX, 20, 0x00FF88);

        String fpsText = "FPS: " + monitor.getFpsMonitor().getCurrentFps() + " (1% Low: " + monitor.getFpsMonitor().getOnePercentLowFps() + ")";
        String frameTimeText = String.format("Frame Time: %.1f ms", monitor.getFrameTimeMonitor().getCurrentFrameTimeMs());
        String memoryText = "RAM Usage: " + monitor.getUsedMemoryMB() + " MB / " + monitor.getMaxMemoryMB() + " MB";
        String profileText = "Active Profile: " + ProfileManager.getInstance().getCurrentProfile().getName();

        context.drawCenteredTextWithShadow(this.textRenderer, fpsText, centerX, 55, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer, frameTimeText, centerX, 70, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer, memoryText, centerX, 85, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer, profileText, centerX, 100, 0x00D0FF);

        super.render(context, mouseX, mouseY, delta);
    }
}
