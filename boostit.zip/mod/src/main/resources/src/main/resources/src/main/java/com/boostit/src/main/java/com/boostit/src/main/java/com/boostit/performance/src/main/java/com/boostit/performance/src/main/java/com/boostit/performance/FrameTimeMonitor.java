package com.boostit.performance;

public class FrameTimeMonitor {
    private static final int BUFFER_SIZE = 120;
    private final float[] frameTimeBuffer = new float[BUFFER_SIZE];
    private int bufferIndex = 0;

    private float currentFrameTimeMs = 0.0f;
    private float averageFrameTimeMs = 0.0f;

    public void recordFrame(long frameDurationNanoseconds) {
        this.currentFrameTimeMs = frameDurationNanoseconds / 1_000_000.0f;

        frameTimeBuffer[bufferIndex] = this.currentFrameTimeMs;
        bufferIndex = (bufferIndex + 1) % BUFFER_SIZE;

        float sum = 0.0f;
        for (float time : frameTimeBuffer) {
            sum += time;
        }
        this.averageFrameTimeMs = sum / BUFFER_SIZE;
    }

    public float getCurrentFrameTimeMs() { return currentFrameTimeMs; }
    public float getAverageFrameTimeMs() { return averageFrameTimeMs; }
}
