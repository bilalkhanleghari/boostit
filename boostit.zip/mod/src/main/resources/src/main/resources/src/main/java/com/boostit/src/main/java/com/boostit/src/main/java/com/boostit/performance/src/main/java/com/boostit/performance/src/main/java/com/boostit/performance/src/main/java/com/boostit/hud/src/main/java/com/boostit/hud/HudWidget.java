package com.boostit.hud;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public abstract class HudWidget {
    protected int x;
    protected int y;
    protected boolean enabled = true;

    public HudWidget(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public abstract void render(DrawContext context, TextRenderer textRenderer);

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public void setPosition(int x, int y) { this.x = x; this.y = y; }
    public int getX() { return x; }
    public int getY() { return y; }
}
