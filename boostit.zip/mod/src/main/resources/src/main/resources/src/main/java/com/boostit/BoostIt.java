package com.boostit;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BoostIt implements ModInitializer {
    public static final String MOD_ID = "boostit";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("[BOOSTIT] Initializing core modules...");
    }
}