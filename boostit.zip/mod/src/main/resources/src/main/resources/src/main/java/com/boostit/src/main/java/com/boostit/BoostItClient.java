package com.boostit;

import com.boostit.commands.BoostItCommand;
import com.boostit.keybinds.KeybindManager;
import com.boostit.performance.PerformanceMonitor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;

@Environment(EnvType.CLIENT)
public class BoostItClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        BoostIt.LOGGER.info("[BOOSTIT] Initializing client performance engine...");

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            BoostItCommand.register(dispatcher);
        });

        KeybindManager.registerKeybinds();

        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);
    }

    private void onClientTick(MinecraftClient client) {
        if (client != null) {
            PerformanceMonitor.getInstance().onRenderTick(client);
        }
    }
}
