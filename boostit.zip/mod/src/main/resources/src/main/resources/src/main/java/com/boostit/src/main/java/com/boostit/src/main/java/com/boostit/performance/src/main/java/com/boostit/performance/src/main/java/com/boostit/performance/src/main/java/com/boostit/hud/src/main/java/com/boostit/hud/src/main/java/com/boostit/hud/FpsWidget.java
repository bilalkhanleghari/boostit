package com.boostit.hud;

import com.boostit.performance.PerformanceMonitor;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public class FpsWidget extends HudWidget {

    public FpsWidget(int x, int y) {
        super(x, y);
    }

    @Override
    public void render(DrawContext context, TextRenderer textRenderer) {
        if (!enabled) return;

        PerformanceMonitor monitor = PerformanceMonitor.getInstance();
        int fps = monitor.getFpsMonitor().getCurrentFps();
        int lowFps = monitor.getFpsMonitor().getOnePercentLowFps();
        float frameTime = monitor.getFrameTimeMonitor().getCurrentFrameTimeMs();

        String fpsText = String.format("FPS: %d | 1%% LOW: %d | %.1fms", fps, lowFps, frameTime);

        int width = textRenderer.getWidth(fpsText) + 6;
        context.fill(x - 2, y - 2, x + width, y + 10, 0x80000000);
        context.drawText(textRenderer, fpsText, x, y, 0x00FF88, true);
    }
}
