package com.boostit.performance;

import net.minecraft.client.MinecraftClient;

public class PerformanceMonitor {
    private static final PerformanceMonitor INSTANCE = new PerformanceMonitor();

    private final FpsMonitor fpsMonitor = new FpsMonitor();
    private final FrameTimeMonitor frameTimeMonitor = new FrameTimeMonitor();

    private long usedMemoryMB = 0;
    private long maxMemoryMB = 0;
    private long lastFrameTimeNano = System.nanoTime();

    private PerformanceMonitor() {}

    public static PerformanceMonitor getInstance() {
        return INSTANCE;
    }

    public void onRenderTick(MinecraftClient client) {
        long currentTimeNano = System.nanoTime();
        long frameDuration = currentTimeNano - lastFrameTimeNano;
        lastFrameTimeNano = currentTimeNano;

        frameTimeMonitor.recordFrame(frameDuration);
        fpsMonitor.recordFps(client.getCurrentFps());
        updateMemoryMetrics();
    }

    private void updateMemoryMetrics() {
        Runtime runtime = Runtime.getRuntime();
        this.maxMemoryMB = runtime.maxMemory() / (1024 * 1024);
        this.usedMemoryMB = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024);
    }

    public FpsMonitor getFpsMonitor() {
        return fpsMonitor;
    }

    public FrameTimeMonitor getFrameTimeMonitor() {
        return frameTimeMonitor;
    }

    public long getUsedMemoryMB() {
        return usedMemoryMB;
    }

    public long getMaxMemoryMB() {
        return maxMemoryMB;
    }
}
