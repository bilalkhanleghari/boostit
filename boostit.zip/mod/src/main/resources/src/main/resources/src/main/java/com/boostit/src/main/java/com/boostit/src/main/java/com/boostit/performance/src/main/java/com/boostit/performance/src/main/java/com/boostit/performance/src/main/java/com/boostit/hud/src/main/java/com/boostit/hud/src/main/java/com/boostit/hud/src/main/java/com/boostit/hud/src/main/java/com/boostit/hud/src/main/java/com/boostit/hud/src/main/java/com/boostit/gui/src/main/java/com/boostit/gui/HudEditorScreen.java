package com.boostit.gui;

import com.boostit.hud.HudManager;
import com.boostit.hud.HudWidget;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class HudEditorScreen extends Screen {
    private HudWidget selectedWidget = null;
    private int dragOffsetX = 0;
    private int dragOffsetY = 0;

    public HudEditorScreen() {
        super(Text.literal("BOOSTIT HUD Editor"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context);

        for (HudWidget widget : HudManager.getInstance().getWidgets()) {
            if (!widget.isEnabled()) continue;

            int wX = widget.getX();
            int wY = widget.getY();
            context.drawBorder(wX - 4, wY - 4, 120, 20, widget == selectedWidget ? 0xFF00FF00 : 0x80FFFFFF);
        }

        context.drawCenteredTextWithShadow(this.textRenderer, "BOOSTIT HUD Editor - Drag widgets to position", this.width / 2, 10, 0xFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            for (HudWidget widget : HudManager.getInstance().getWidgets()) {
                if (mouseX >= widget.getX() - 4 && mouseX <= widget.getX() + 116 &&
                    mouseY >= widget.getY() - 4 && mouseY <= widget.getY() + 16) {
                    selectedWidget = widget;
                    dragOffsetX = (int) mouseX - widget.getX();
                    dragOffsetY = (int) mouseY - widget.getY();
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (selectedWidget != null) {
            selectedWidget.setPosition((int) mouseX - dragOffsetX, (int) mouseY - dragOffsetY);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        selectedWidget = null;
        return super.mouseReleased(mouseX, mouseY, button);
    }
}
