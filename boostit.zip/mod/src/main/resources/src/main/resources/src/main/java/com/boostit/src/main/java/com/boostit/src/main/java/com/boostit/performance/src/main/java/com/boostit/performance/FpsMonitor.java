package com.boostit.performance;

import java.util.Arrays;

public class FpsMonitor {
    private static final int HISTORY_CAPACITY = 100;
    private final int[] fpsHistory = new int[HISTORY_CAPACITY];
    private int historyIndex = 0;
    private int recordedCount = 0;

    private int currentFps = 0;
    private int averageFps = 0;
    private int onePercentLowFps = 0;

    public void recordFps(int newFps) {
        this.currentFps = newFps;
        fpsHistory[historyIndex] = newFps;
        historyIndex = (historyIndex + 1) % HISTORY_CAPACITY;

        if (recordedCount < HISTORY_CAPACITY) {
            recordedCount++;
        }

        recalculateStats();
    }

    private void recalculateStats() {
        if (recordedCount == 0) return;

        int[] activeSamples = Arrays.copyOf(fpsHistory, recordedCount);
        Arrays.sort(activeSamples);

        long sum = 0;
        for (int sample : activeSamples) {
            sum += sample;
        }
        this.averageFps = (int) (sum / recordedCount);

        int onePercentIndex = Math.max(0, (int) Math.floor(recordedCount * 0.01));
        this.onePercentLowFps = activeSamples[onePercentIndex];
    }

    public int getCurrentFps() { return currentFps; }
    public int getAverageFps() { return averageFps; }
    public int getOnePercentLowFps() { return onePercentLowFps; }
}
