package com.boostit.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import java.util.ArrayList;
import java.util.List;

public class HudManager {
    private static final HudManager INSTANCE = new HudManager();
    private final List<HudWidget> widgets = new ArrayList<>();

    private HudManager() {
        widgets.add(new FpsWidget(10, 10));
        widgets.add(new PingWidget(10, 24));
        widgets.add(new CpsWidget(10, 38));
        widgets.add(new KeystrokesWidget(10, 56));
    }

    public static HudManager getInstance() { return INSTANCE; }

    public void render(DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.options.hudHidden) return;

        for (HudWidget widget : widgets) {
            widget.render(context, client.textRenderer);
        }
    }

    public List<HudWidget> getWidgets() { return widgets; }
}
