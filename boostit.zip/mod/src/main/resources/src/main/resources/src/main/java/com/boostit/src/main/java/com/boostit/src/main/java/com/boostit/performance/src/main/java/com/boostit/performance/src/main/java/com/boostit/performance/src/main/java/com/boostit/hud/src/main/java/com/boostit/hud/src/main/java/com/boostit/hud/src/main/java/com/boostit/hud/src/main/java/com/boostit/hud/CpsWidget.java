package com.boostit.hud;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import java.util.ArrayList;
import java.util.List;

public class CpsWidget extends HudWidget {
    private static final List<Long> leftClicks = new ArrayList<>();
    private static final List<Long> rightClicks = new ArrayList<>();

    public CpsWidget(int x, int y) {
        super(x, y);
    }

    public static void onLeftClick() { leftClicks.add(System.currentTimeMillis()); }
    public static void onRightClick() { rightClicks.add(System.currentTimeMillis()); }

    @Override
    public void render(DrawContext context, TextRenderer textRenderer) {
        if (!enabled) return;

        long now = System.currentTimeMillis();
        leftClicks.removeIf(time -> now - time > 1000);
        rightClicks.removeIf(time -> now - time > 1000);

        String cpsText = String.format("CPS: %d | %d", leftClicks.size(), rightClicks.size());
        int width = textRenderer.getWidth(cpsText) + 6;

        context.fill(x - 2, y - 2, x + width, y + 10, 0x80000000);
        context.drawText(textRenderer, cpsText, x, y, 0xFFFFAA, true);
    }
}
