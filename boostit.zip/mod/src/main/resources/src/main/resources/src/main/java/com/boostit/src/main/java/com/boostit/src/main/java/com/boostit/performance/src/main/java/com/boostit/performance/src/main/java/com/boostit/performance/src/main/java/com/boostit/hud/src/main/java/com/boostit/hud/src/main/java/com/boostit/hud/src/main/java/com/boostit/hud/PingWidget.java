package com.boostit.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;

public class PingWidget extends HudWidget {

    public PingWidget(int x, int y) {
        super(x, y);
    }

    @Override
    public void render(DrawContext context, TextRenderer textRenderer) {
        if (!enabled) return;

        MinecraftClient client = MinecraftClient.getInstance();
        int ping = getPing(client);

        String pingText = String.format("PING: %d ms", ping);
        int width = textRenderer.getWidth(pingText) + 6;

        context.fill(x - 2, y - 2, x + width, y + 10, 0x80000000);
        context.drawText(textRenderer, pingText, x, y, 0x00D0FF, true);
    }

    private int getPing(MinecraftClient client) {
        if (client.player == null) return 0;
        ClientPlayNetworkHandler networkHandler = client.getNetworkHandler();
        if (networkHandler != null) {
            PlayerListEntry entry = networkHandler.getPlayerListEntry(client.player.getUuid());
            if (entry != null) {
                return entry.getLatency();
            }
        }
        return 0;
    }
}
