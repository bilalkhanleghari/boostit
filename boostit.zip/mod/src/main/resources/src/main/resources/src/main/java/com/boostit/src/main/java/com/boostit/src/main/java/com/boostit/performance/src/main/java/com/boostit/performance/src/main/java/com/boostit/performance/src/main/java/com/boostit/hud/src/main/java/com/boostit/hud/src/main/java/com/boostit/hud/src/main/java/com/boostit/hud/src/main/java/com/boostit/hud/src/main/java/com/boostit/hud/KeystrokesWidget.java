package com.boostit.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public class KeystrokesWidget extends HudWidget {

    public KeystrokesWidget(int x, int y) {
        super(x, y);
    }

    @Override
    public void render(DrawContext context, TextRenderer textRenderer) {
        if (!enabled) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.options == null) return;

        boolean w = client.options.forwardKey.isPressed();
        boolean a = client.options.leftKey.isPressed();
        boolean s = client.options.backKey.isPressed();
        boolean d = client.options.rightKey.isPressed();

        int size = 18;
        int gap = 2;

        drawKey(context, textRenderer, x + size + gap, y, size, size, "W", w);
        drawKey(context, textRenderer, x, y + size + gap, size, size, "A", a);
        drawKey(context, textRenderer, x + size + gap, y + size + gap, size, size, "S", s);
        drawKey(context, textRenderer, x + (size + gap) * 2, y + size + gap, size, size, "D", d);
    }

    private void drawKey(DrawContext context, TextRenderer textRenderer, int kX, int kY, int width, int height, String label, boolean pressed) {
        int bgColor = pressed ? 0xC0FFFFFF : 0x80000000;
        int textColor = pressed ? 0x000000 : 0xFFFFFF;

        context.fill(kX, kY, kX + width, kY + height, bgColor);
        int textWidth = textRenderer.getWidth(label);
        context.drawText(textRenderer, label, kX + (width - textWidth) / 2, kY + (height - 8) / 2, textColor, !pressed);
    }
}
